package ar.com.portfolio.ldm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LdmApplicationTests {

	@Test
	void contextLoads() {
	}

}
